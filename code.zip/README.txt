In order to run this project, make sure the game you are looking to analyze is not already finished since the Twitter stream won't be as useful.

To run this app:
python userInterface.py
